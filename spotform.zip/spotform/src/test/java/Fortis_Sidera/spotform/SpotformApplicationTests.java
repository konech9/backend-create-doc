package Fortis_Sidera.spotform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotformApplicationTests {

	@Test
	void contextLoads() {
	}

}
